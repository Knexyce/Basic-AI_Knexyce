import json
import re
import os
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_screen()

import os
import json
import re

class QuestionInterpreter:
    def __init__(self, questions_file, answers_file):
        self.questions = self.load_questions(questions_file)
        self.answers = self.load_answers(answers_file)

    def load_questions(self, questions_file):
        with open(questions_file, "r") as file:
            questions_data = json.load(file)
        return questions_data.get('questions', [])

    def load_answers(self, answers_file):
        with open(answers_file, "r") as file:
            answers_data = json.load(file)
        return answers_data.get('answers', {})

    def interpret_question(self, user_input):
        user_input = user_input.lower()
        for question in self.questions:
            question_words = question.lower().replace('?', '').split()
            if all(word in user_input for word in question_words):
                return question
        return None

    def get_answer(self, question):
        for q, answer in self.answers.items():
            if q.lower() in question.lower():
                return answer
        return None

class KeywordExtractor:
    def __init__(self, num_keywords=3):
        self.num_keywords = num_keywords
        self.stopwords = self.load_stopwords()

    def load_stopwords(self):
        return {"is", "are", "am", "was", "were", "be", "been", "being", "a", "an", "the", "of", "in", "on", "at", "to", "for", "with", "by", "as", "this", "that", "these", "those", "it", "its", "they", "their", "them", "i", "you", "your", "he", "his", "him", "she", "her", "we", "our", "us", "who", "whom", "whose", "what", "which", "where", "when", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "not", "nor", "only", "own", "so", "than", "too", "very", "just", "now"}

    def extract_keywords(self, question):
        words = re.findall(r'\w+', question.lower())
        filtered_words = [word for word in words if word not in self.stopwords]
        keyword_counter = {}
        for word in filtered_words:
            keyword_counter[word] = keyword_counter.get(word, 0) + 1
        sorted_keywords = sorted(keyword_counter, key=keyword_counter.get, reverse=True)
        return sorted_keywords[:self.num_keywords]

class QuestionAnswerSystem:
    def __init__(self, questions_file, answers_file):
        self.qa_interpreter = QuestionInterpreter(questions_file, answers_file)
        self.keyword_extractor = KeywordExtractor()

    def list_keywords(self):
        for question, answer in zip(self.qa_interpreter.questions, self.qa_interpreter.answers.values()):
            keywords = self.keyword_extractor.extract_keywords(question)
            print("Question:", question)
            print("Keywords:", keywords)
            print("Answer:", answer)
            print()

def KnexyceAI():
    clear_screen()
    qa_system = QuestionAnswerSystem("questions.json", "Info.json")
    print("KAI (KnexyceAI)")
    print("Ask me a question, and I'll do my best to answer it.")
    while True:
        user_input = input("User@KAI: ").strip()
        if user_input.lower() == "info:knexyce":
            try:
                with open("Information.txt", "r") as fileInf:
                    readinf = fileInf.read()
                    print(readinf)
            except FileNotFoundError:
                print("KAI: Error - Information.txt not found in the directory.")
        elif user_input.lower() == "exit":
            print("Goodbye.")
            print("KAI has exited.")
            break
        else:
            interpreted_question = qa_system.qa_interpreter.interpret_question(user_input)
            if interpreted_question:
                answer = qa_system.qa_interpreter.get_answer(interpreted_question)
                if answer:
                    print("KAI:", answer)
                else:
                    print("KAI: Sorry, I couldn't find an answer to that question.")
            else:
                print("KAI: Error may have occurred.")

def startKAI():
    clear_screen()
    KnexyceAI()

startKAI()